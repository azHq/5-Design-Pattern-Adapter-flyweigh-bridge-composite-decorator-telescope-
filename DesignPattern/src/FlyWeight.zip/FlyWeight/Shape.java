package FlyWeight;

public abstract class Shape {
	
	public abstract void draw(int x,int y);

}
