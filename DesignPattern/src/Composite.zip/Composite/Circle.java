package Composite;

public class Circle extends BasicShape {

	@Override
	public void draw() {
			
		System.out.println("Draw Circle");
	}
}
