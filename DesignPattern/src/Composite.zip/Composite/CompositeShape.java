package Composite;

import java.util.ArrayList;

public abstract class CompositeShape implements IShape{

	ArrayList<IShape> shapes=new ArrayList<>();
	@Override
	public void draw() {
			
		for(IShape shape:shapes) {
			
			buildShape();
			shape.draw();
		}
	}
	
	public abstract void buildShape();

}
