package Composite;

public class BasicShape implements IShape{

	@Override
	public void draw() {
			
		
	}
}
