package Composite;

public class MainClass {

	public static void main(String[] args) {
		
		Flag flag=new Flag();
		flag.draw();
	}

}
