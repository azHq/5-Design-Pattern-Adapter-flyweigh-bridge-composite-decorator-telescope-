package Composite;

public class Line extends BasicShape {
	
	
	@Override
	public void draw() {
		
		System.out.println("Draw Line");
	}
}
