package Composite;

public interface IShape {

	public abstract void  draw();
}
