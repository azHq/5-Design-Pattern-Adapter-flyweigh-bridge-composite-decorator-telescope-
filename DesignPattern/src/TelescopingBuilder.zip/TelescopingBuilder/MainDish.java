package TelescopingBuilder;

public abstract class MainDish {
	
	public abstract double getPrice();
	public abstract int getQuantity();
	public abstract String getName();
	

}
