package TelescopingBuilder;

public abstract class Gift {
	
	public abstract String getName();
	public abstract int getQuantity();

}
